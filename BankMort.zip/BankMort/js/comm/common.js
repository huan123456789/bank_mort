﻿
function GetAjaxData(urlstr, type) {
    $.ajax({
        timeout: 36000, //请求超时时间（毫秒）
        async: true, //异步
        dataType: "html", //
        beforeSend: function () {
//            showLoader();
        },
        complete: function () {
//            hideLoader();
        },
        url: urlstr,
        success: function (data) {
            if (type == "1") {
                addDataToList1(data);
            } else if (type == "2") {
                addDataToList2(data);
            } else if (type == "3") {
                addDataToList3(data);
            } else if (type == "4") {
                addDataToList4(data);
            } else if (type == "5") {
                addDataToList5(data);
            } else if (type == "6") {
                addDataToList6(data);
            } else if (type == "7") {
                addDataToList7(data);
            }

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("请求异常信息：" + textStatus);
            addDataToList('');
            this;   //调用本次ajax请求时传递的options参数
        }
    });
}

function GetAjaxData_common(urlstr, fun) {
    $.ajax({
        timeout: 36000, //请求超时时间（毫秒）
        async: true, //异步
        dataType: "html", //
        beforeSend: function () {
//            showLoader();
        },
        complete: function () {
//            hideLoader();
        },
        url: urlstr,
        success: function (data) {
            //alert("返回数据：" + data);
            fun.call(this, data);
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("异常信息：" + textStatus);
            this;   //调用本次ajax请求时传递的options参数
        }
    });
}

function GetAjaxData2(urlstr, type) {
    $.ajax({
        timeout: 36000, //请求超时时间（毫秒）
        async: true, //异步
        dataType: type, //     
        url: urlstr, //"../asyncinvoke/houseListMore.aspx?type=1&pageno=1&pagesize=20", //"接口地址?param1=p1&param2=p2",
        success: function (data) {
            //alert("返回数据：" + data);
            addDataToList(data);
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("异常信息：" + textStatus);
            this;   //调用本次ajax请求时传递的options参数
        }
    });
}

function PostAjaxData(urlstr, data) {
//    $.ajax({
//        timeout: 36000, //请求超时时间（毫秒）
//        async: true, //异步
//        dataType: type, //     
//        url: urlstr, //"../asyncinvoke/houseListMore.aspx?type=1&pageno=1&pagesize=20", //"接口地址?param1=p1&param2=p2",
//        success: function (data) {
//            //alert("返回数据：" + data);
//            addDataToList(data);
//        },
//        error: function (XMLHttpRequest, textStatus, errorThrown) {
//            alert("异常信息：" + textStatus);
//            this;   //调用本次ajax请求时传递的options参数
//        }
//    });
    $.ajax({
        timeout: 36000, //请求超时时间（毫秒）
        async: true, //异步
        type: 'POST',
        url: urlstr,
        data: data,
        success: function (rdata) {
            addDataToListPost(rdata);
        },
        dataType: "json"
    });
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return '';
}
//function showLoader() {
//    //显示加载器.for jQuery Mobile 1.2.0  以上
//    $.mobile.loading('show', {
//        text: '数据加载中，请稍候', //加载器中显示的文字  
//        textVisible: true, //是否显示文字  
//        theme: 'a',        //加载器主题样式a-e  
//        textonly: false,   //是否只显示文字  
//        html: ""           //要显示的html内容，如图片等，默认使用Theme里的ajaxLoad图片  
//    });
//}
//function hideLoader() {
//    //隐藏加载器  
//    $.mobile.loading('hide');
//}

