﻿function asyncAjax(url, data, successfn, errorfn) {//异步加载
    data = (data == null || data == "" || typeof (data) == "undefined") ? { "date": new Date().getTime()} : data;
    $.ajax({
        type: "post",
        async: true,
        data: data,
        url: url,
        dataType: "json",
        success: function (d) {
            successfn(d);
        },
        error: function (e) {
            if (errorfn) {
                errorfn(e);
            } else {
                showerrormsgForAjax(e)
            }
        }
    });
};
function asyncAjax2(url, data, successfn, errorfn) {//同步加载
    data = (data == null || data == "" || typeof (data) == "undefined") ? { "date": new Date().getTime()} : data;
    $.ajax({
        type: "post",
        async: false,
        data: data,
        url: url,
        dataType: "json",
        success: function (d) {
            successfn(d);
        },
        error: function (e) {
            if (errorfn) {
                errorfn(e);
            } else {
                showerrormsgForAjax(e)
            }
        }
    });
};


function showerrormsgForAjax(model) {
    var msg = "";
//    for (var key in model) {
//        msg += key + ':' + model[key];
//    }
    layer.open({
        content: msg
        , anim: 'up'
        , skin: 'footer'
        , style: ' color:red'
        , end: function () {
            setTimeout(" closelayer();", "300");
        }
    });
}