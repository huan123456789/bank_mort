var storage = window.localStorage;
var common = {
    /**
    * 生成浏览器标识
    */
    makeDeviceCode: function () {
        return common.makeUUid(8, 10);
    },
    /**
    *获取地理坐标 'lng': '120.146', 'lat': '30.286'
    */
    getPosition: function () {
        if (storage.getItem("VPIAO_MOBILE_POSITION") == null) {
            var p = { 'lng': '0', 'lat': '0' };
            storage.setItem('VPIAO_MOBILE_POSITION', JSON.stringify(p));
            return p;
        } else {
            return JSON.parse(storage.getItem('VPIAO_MOBILE_POSITION'));
        }
    },
    /**
    * from表单数据转换成json数据
    * 
    * @param fromId
    *            from表单ID 请填写"#表单ID" return jsonObject
    */
    formToJson: function (fromId) {
        var data = $(fromId).serialize(); // 获取表单值
        data = decodeURIComponent(data, true); // 防止中文乱码
        data = data.replace(/&/g, "\",\"");
        data = data.replace(/=/g, "\":\"");
        data = "{\"" + data + "\"}";
        var params = $.parseJSON(data); // 转化为json
        return params;
    },
    formToJsonStr: function (fromId) {
        var data = $(fromId).serialize(); // 获取表单值
        data = decodeURIComponent(data, true); // 防止中文乱码
        data = data.replace(/&/g, "\",\"");
        data = data.replace(/=/g, "\":\"");
        data = "{\"" + data + "\"}";
        return data;
    },
    post: function (uri, params) {
        /** 模拟from表单提交 uri action地址 currPageNum 当前链接的页数 */
        var temp = document.createElement("form");
        temp.action = uri;
        temp.method = "post";
        temp.style.display = "none";
        for (var x in params) {
            var opt = document.createElement("input");
            opt.name = x;
            opt.value = params[x];
            temp.appendChild(opt);
        }
        document.body.appendChild(temp);
        temp.submit();
    },
    /**
    * 非房源添加日志 userMobile 用户手机号 deviceCode 设备号 
    * @param returnCitySN 地区信息
    */
    emactionType: {
        '浏览': '1001', '找相似': '1002', '收藏': '1003', '加入想看': '1004', '预约看房': '1005',
        '微信联系': '1006', '联系_QQ': '1007', '咨询_IM': '1008', '分享': '1009', '扫码': '1010'
    },
    showLog: true,
    addActionLog: function () {
        if (!common.showLog) return;
        if (!returnCitySN)
            returnCitySN = { "cip": "0.0.0.0", "cid": "000000", "cname": "" };
        var deviceCode = '';
        if (storage.getItem("deviceCode") == null) {
            deviceCode = common.makeDeviceCode();
            storage.setItem("deviceCode", deviceCode);
        } else {
            deviceCode = storage.getItem("deviceCode");
        }
        var jsonString = {
            "userMobile": "",
            "deviceCode": deviceCode,
            "actionType": '1001',
            "curLocation": window.location.href,
            "beforeLocation": document.referrer,
            "deviceType": 2,
            "ipAddress": returnCitySN.cip,
            "addressCode": returnCitySN.cid,
            "provincesCities": returnCitySN.cname
        };
        common.addLog(jsonString);
    },
    /**
    * 房源添加行为日志
    * @param actionType 行为动作 此值与分析系统字典表保持一致 common.emactionType.浏览
    * @param houseCode 房源编号
    * @param price 租金或房价 
    * @param area 面积
    * @param rooms 几居室
    * @param orientation 朝向
    * @param tags 标签字符串用竖线分隔
    * @param storeyCount 总楼层
    * @param decorationId 装修程度 int枚举值
    * @param returnCitySN 地理信息
    */
    addHouseActionLog: function (actionType, houseCode, price, area, rooms, orientation, tags, storeyCount, decorationId) {
        if (!common.showLog) return;
        if (!returnCitySN)
            returnCitySN = { "cip": "0.0.0.0", "cid": "000000", "cname": "" };
        var deviceCode = '';
        if (storage.getItem("deviceCode") == null) {
            deviceCode = common.makeDeviceCode();
            storage.setItem("deviceCode", deviceCode);
        } else {
            deviceCode = storage.getItem("deviceCode");
        }
        console.info(houseCode);
        var jsonString = {
            "userMobile": "",
            "deviceCode": deviceCode,
            "actionType": actionType,
            "houseCode": houseCode,
            "price": price,
            "area": area,
            "rooms": rooms,
            "orientation": orientation,
            "tags": tags,
            "storeyCount": storeyCount,
            "decorationId": decorationId,
            "curLocation": window.location.href,
            "beforeLocation": document.referrer,
            "deviceType": 2,
            "ipAddress": returnCitySN.cip,
            "addressCode": returnCitySN.cid,
            "provincesCities": returnCitySN.cname
        };
        common.addLog(jsonString);
    },
    /**
    * 提交行为日志
    */
    addLog: function (param) {
        $.ajax({
            type: "POST",
            async: false,
            contentType: "application/json",
            data: JSON.stringify(param),
            url: 'http://analysis.hshb.cn/actionLog/add',
            dataType: "json",
            success: function (data) {
                console.info(data);
            }
        });
    },
    /**
    * 设置浏览器唯一设备标识
    */
    addDeviceCode: function () {
        storage.setHbDeviceCode();
    },
    /**
    * 判断是否是手机号
    */
    isMoblie: function (s) {
        var str = s;
        var reg = /^(13[0-9]|15[012356789]|18[012356789]|14[57]|17[05678])[0-9]{8}$/;

        if (reg.test(str)) {
            return true;
        } else {
            return false;
        }
    },
    isCard: function (s) {
        var str = s;
        var reg = /\d{15}(\d\d[0-9xX])?/;

        if (reg.test(str)) {
            return true;
        } else {
            return false;
        }
    },
    /**
    * 判断是否为空
    */
    isEmpty: function (s) {
        var str = s;
        if (str == null || str == "") {
            return true;
        } else {
            return false;
        }
    },
    /**
    * 清空下拉框的值,只保留第一个值
    */
    clearSelect: function (id) {
        var sel = document.getElementById(id);
        if (sel) {
            sel.options.length = 1;
            sel.options[0].selected = true;
        }
    },
    getNowTime: function () {
        // 取得当前时间
        var now = new Date();
        var year = now.getFullYear();
        var month = now.getMonth() + 1;
        var day = now.getDate();
        var hour = now.getHours();
        var minute = now.getMinutes();
        var second = now.getSeconds();
        var nowdate = year + (month < 10 ? "0" : "") + month
            + (day < 10 ? "0" : "") + day + (hour < 10 ? "0" : "") + hour
            + (minute < 10 ? "0" : "") + minute;
        return nowdate;
    },

    /**
    * 显示微信，参数为点击的元素，其中自定义属性‘data-url’为微信图片地址， ‘data-onlyId’为唯一ID，与隐藏的Div相册ID相同
    */
    showWeixin: function (obj) {
        var url = $(obj).attr("data-url");
        var brokerId = $(obj).attr("data-onlyId");
        var contents = '<img src="' + url
            + '" style="height: 100%;width: 100%"/>';

        var imgW = common.getImgW(brokerId);
        var imgH = common.getImgH(brokerId);
        layer.open({
            type: 1,
            title: '经纪人微信',
            skin: 'layui-layer-rim', // 加上边框
            shadeClose: true,
            shade: 0.8,
            area: [imgW + 'px', imgH + 'px'], // 宽高
            content: contents
        });

    },
    /**
    * 显示微信，参数为点击的元素，其中自定义属性‘data-url’为微信图片地址，子页面，透明度为0
    * ‘data-onlyId’为唯一ID，与隐藏的Div相册ID相同
    */
    showWeixin2: function (obj) {
        var url = $(obj).attr("data-url");
        var brokerId = $(obj).attr("data-onlyId");
        var contents = '<img src="' + url
            + '" style="height: 100%;width: 100%"/>';

        var imgW = common.getImgW(brokerId);
        var imgH = common.getImgH(brokerId);
        layer.open({
            type: 1,
            title: '经纪人微信',
            skin: 'layui-layer-rim', // 加上边框
            shadeClose: true,
            shade: 0,
            area: [imgW + 'px', imgH + 'px'], // 宽高
            content: contents
        });

    },
    /**
    * 获取图片宽度
    */
    getImgW: function (oImg) {
        // 兼容所有浏览器的方法
        var obj = new Image();
        obj.src = document.getElementById(oImg).src;
        var w = obj.width;
        obj.complete ? w = obj.width : w = this.width;
        if (w > 200) {
            return w / 2;
        } else if (w < 100) {
            return w * 2;
        } else {
            return w;
        }
    },
    /**
    * 获取图片高度
    */
    getImgH: function (oImg) {
        // 兼容所有浏览器的方法
        var obj1 = new Image();
        obj1.src = document.getElementById(oImg).src;
        var h = obj1.height;
        var w = obj1.width;
        obj1.complete ? h = obj1.height : h = this.height;
        if (w > 200) {
            return h / 2;
        } else if (w < 100) {
            return h * 2;
        } else {
            return h;
        }
    },
    /**
    * 显示弹窗二维码
    *
    * @param url
    *            需要转换为二维码的URL地址
    */
    showZxing: function (url) {
        layer.open({
            type: 2,
            title: '扫描二维码',
            shadeClose: true,
            shade: 0.8,
            area: ['240px', '285px'],
            content: [url, 'no']

        });
    },
    fenXiang: function (url) {
        layer.open({
            type: 2,
            title: '手机扫描分享',
            shadeClose: true,
            shade: 0.8,
            area: ['240px', '285px'],
            content: [url, 'no']

        });
    },
    /*
    * 分享开始 分享内容请写到common.js里
    */
    // 分享 创建一个分享按钮对应的链接地址现在只添加了腾讯微博和新浪微博
    shareIco: {
        "tqq": "http://v.t.qq.com/share/share.php?title={title}&url={url}",
        "tsina": "http://service.weibo.com/share/share.php?title={title}&url={url}",
        "trrw": "http://widget.renren.com/dialog/share?resourceUrl={url}&srcUrl={url}&title={title}&description=",
        "tdbw": "http://www.douban.com/share/service?href={url}&name={title}&text="
    },
    shareIcoName: {
        "tqq": "腾讯微博",
        "tsina": "新浪微博",
        "trrw": "人人网",
        "tdbw": "豆瓣网"
    },
    shareInformation: function (key) {
        // 店铺名店铺链接地址
        var content = $("#shopName").attr("value");
        var shopUrl = $("#broderWebShop").attr("value");
        content += "【" + $("#broderWebShop").attr("value") + "】";
        // 利用正则表达式 把值给替换
        window.open(common.formatModel(common.shareIco[key], {
            title: content,
            url: shopUrl
        }));
    },
    formatModel: function (str, model) {
        for (var k in model) {
            var re = new RegExp("{" + k + "}", "g");
            str = str.replace(re, model[k]);
        }
        return str;
    }
    /* 分享结束 */
    ,
    // 点击图片显示小区大图
    layerShow: function (id) {
        layer.photos({
            photos: '#' + id,
            shift: 0
        });
    },
    testIsMiMa: function (pass) {
        var reg = /^[a-z0-9_-]{6,14}$/;
        return reg.test(pass)
    },
    /**
    * 判断是否为正整数
    */
    testIsInteger: function (str) {
        var reg = /^[0-9]*[1-9][0-9]*$/;
        return reg.test(str)
    },
    /**
    * 判断是否为数字
    */
    testIsNum: function (str) {
        var reg = /^[0-9]+.?[0-9]*$/;
        return reg.test(str)
    },
    /**
    * 未登录状态跳转到登录页面 登录状态则关注 param memberId 会员ID param interestId 关注对象ID 例如 学区ID
    * 二手房ID param type 1-二手房 2-租房 3-新房 4-小区 5-学区 param ctx
    * 上下文地址，配置在common_inport_js.jsp页面全局参数里
    */
    memberInterest: function (memberId, houseId, type) {
        if ($("#" + houseId).text() == "已收藏") {
            layer.msg('您已收藏过本房源，无需再次收藏', {
                time: 2000,
                icon: 6
            });
            return false;
        }
        if (memberId != 0) {
            $.ajax({
                type: "get",
                url: ctx + "/member/ajax_memberInterest",
                data: {
                    'memberId': memberId,
                    'interestId': houseId,
                    'type': type
                },
                success: function (data) {
                    if (data == "true") {
                        layer.msg('收藏成功！您可以到会员中心查看', {
                            time: 2000,
                            icon: 6
                        });
                        $('[id="' + houseId + '"]').text("已收藏");
                    } else {
                        layer.msg('您已收藏过本房源，无需再次收藏', {
                            time: 2000,
                            icon: 5
                        });
                    }
                }
            });
        } else {
            var url = ctx + "/pages/manage/loginAndRegist/login.jsp?preurl="
                + parent.location.href;
            window.location.href = url;
            window.parent.location.href = url;
        }
    },
    /**
    * 页面与经纪人对话窗口 param clientId 客户ID param clientPic 客户头像 Param brokerId 经纪人ID
    * Param brokerPic 经纪人头像 param houseNo 房源编号 param houseType 房屋类型 param
    * houseCover 房屋封面图片 param area 面积 param roomNum 几室 param address 地址 param
    * totalPrice 总价
    */
    dailogBox: function (communityErpId, clientId, clientPic, brokerId,
                         brokerPic, houseNo, houseType, // 房源类型 1 二手房 2 出租房 3 新房 4 小区 5 学区
                         houseCover, // 房屋封面图片
                         area, // 面积
                         roomNum, // 几室
                         address, // 地址
                         buildyear, // 建筑年代
                         price, // 价格
                         title // 标题
    ) {
        if (clientPic.indexOf("noFindPic") > 0) {
            clientPic = ctx + "/static/images/member/abouIcon.png";
        }
        if (clientId != 0) {
            layer.open({
                type: 2,
                title: '豪世华邦-在线沟通',
                closeBtn: 1, // 不显示关闭按钮
                shade: [0],
                area: ['775px', '570px'],
                offset: 'rb', // 右下角弹出
                shift: 2,
                content: [
                    ctx + "/im/createDialog?communityErpId="
                    + communityErpId + "&clientId=" + clientId
                    + "&clientPic=" + clientPic + "&brokerId="
                    + brokerId + "&brokerPic=" + brokerPic
                    + "&houseNo=" + houseNo + "&houseType="
                    + houseType + "&houseCover=" + houseCover
                    + "&area=" + area + "&roomNum=" + roomNum
                    + "&address=" + address + "&buildyear="
                    + buildyear + "&price=" + price + "&title="
                    + title, 'no']
                // ctx
                // 请在页面初始化
            });
        } else {
            window.location.href = ctx
                + "/pages/manage/loginAndRegist/login.jsp?preurl="
                + location.href;
        }
    },
    /**
    * 合同在线咨询窗口、维修单咨询窗口 param type 业务类型 1：合同咨询 2：维修单咨询 param clientId 客户ID param
    * clientPic 客户头像 Param brokerId 经纪人ID Param brokerPic 经纪人头像 param options
    * exts参数
    */
    dailogComBox: function (type, clientId, clientPic, brokerId, brokerPic,
                            options) {
        if (clientPic.indexOf("noFindPic") > 0) {
            clientPic = ctx + "/static/images/member/abouIcon.png";
        }
        if (brokerPic.indexOf("noFindPic") > 0) {
            brokerPic = ctx + "/static/images/member/abouIcon.png";
        }
        if (clientId != 0) {
            layer.open({
                type: 2,
                title: '豪世华邦-在线沟通',
                closeBtn: 1, // 不显示关闭按钮
                shade: [0],
                area: ['775px', '570px'],
                offset: 'rb', // 右下角弹出
                shift: 2,
                content: [
                    ctx + "/im/createComDialog?type=" + type + "&clientId="
                    + clientId + "&clientPic=" + clientPic
                    + "&brokerId=" + brokerId + "&brokerPic="
                    + brokerPic + this.addParams(options), 'no']
                // ctx
                // 请在页面初始化
            });
        } else {
            window.location.href = ctx
                + "/pages/manage/loginAndRegist/login.jsp?preurl="
                + location.href;
        }
    },
    /**
    * 拼接参数
    */
    addParams: function (options) {
        var temp = '';
        for (var name in options) {
            temp += '&' + name + '=' + options[name];
        }
        return temp;
    },
    /**
    * 预约对话框 param houseType 1：买卖，2：租赁 param houseNo 房源编号 param memberId 会员ID
    */
    appointmentDailog: function (houseType, houseNo, memberId) {
        if (memberId == 0) {
            // 重定向到登录页面
            window.location.href = ctx
                + "/pages/manage/loginAndRegist/login.jsp?preurl="
                + location.href;
        } else {
            // 异步插入到预约看房表
            $('#yuyue' + houseNo).html("已预约");
            $('#yuyue' + houseNo).attr("onclick", "");
            $.ajax({
                type: "get",
                url: ctx + "/member/seeHouse/ajax_appointment",
                data: {
                    'memberId': memberId,
                    'houseType': houseType,
                    'houseNo': houseNo
                },
                success: function (data) {
                    if (data.result == 'isHaved') {
                        layer.alert("您已经预约过啦，请耐心等待，经纪人会第一时间与您联系，请保持手机畅通。", {
                            closeBtn: 0,
                            shift: 4, // 动画类型
                            title: '温馨提示'
                        });
                    } else {
                        layer.open({
                            type: 2,
                            title: '预约看房',
                            closeBtn: 1, // 不显示关闭按钮
                            shadeClose: true,
                            shade: 0.6,
                            area: ['540px', '280px'],
                            content: [ctx
                            + '/member/seeHouse/showDailog?return='
                            + data.result + '&seeHouseId='
                            + data.seeHouseId + '&houseId=' + houseNo]
                            // ctx
                            // 请在页面初始化
                        });
                    }
                }
            });
        }
    },
    /**
    * param brokerId 经纪人ID param type 类型ID 1：成交，2：带看，4：勘察，8：出售委托，16：独家出售委托
    */
    appraiseDailog: function (brokerId, type, memberId, recoredId) {
        layer.open({
            type: 2,
            title: '预约看房',
            closeBtn: 1, // 不显示关闭按钮
            shadeClose: true,
            shade: 0.6,
            area: ['440px', '350px'],
            content: [ctx + '/member/appraise/appraiseBrokerDailog?brokerId='
            + brokerId + '&type=' + type + '&memberId=' + memberId
            + '&recoredId=' + recoredId]
            // ctx
            // 请在页面初始化
        });
    },

    /**
    * coverImage：图片地址 type：1、二手房，2、租房，3、新房，4、小区，5、经纪人
    */
    replacePicUri: function (coverImage) {
        if (coverImage.indexOf("http") > -1) {
            return coverImage;
        } else {
            return "http://hz.hshb.cn/frontImages" + coverImage;
        }
    },
    /**
    * 关闭layer弹窗
    */
    closeOpen: function () {
        layer.closeAll();
    },
    // 全局倒计时秒数
    timer: 120,
    getCompetitivePower: function (url_param) {
        $.ajax({
            url: url_param,
            type: "POST",
            success: function (data, stats) {
                $("#commu").text(data.commu);
                $("#cbd").text(data.cbd);
                $("#com_salesHeat").text(data.com_salesHeat);
                $("#com_salesHeat").parent().next().children().css("width",
                    data.com_salesHeat + "%");

                $("#cbd_salesHeat").text(data.cbd_salesHeat);
                $("#cbd_salesHeat").parent().next().children().css("width",
                    data.cbd_salesHeat + "%");

                $("#com_power").text(data.com_power);
                $("#com_power").parent().next().children().css("width",
                    data.com_power + "%");

                $("#cbd_power").text(data.cbd_power);
                $("#cbd_power").parent().next().children().css("width",
                    data.cbd_power + "%");

            },
            error: function (data) {
                sonsole.log("请求失败");
            }
        });
    },
    /**
    * 生成JS版本UUID len 指定长度 radix 随机数
    */
    makeUUid: function (len, radix) {
        var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
            .split('');
        var uuid = [], i;
        radix = radix || chars.length;
        if (len) {
            for (i = 0; i < len; i++)
                uuid[i] = chars[0 | Math.random() * radix];
        } else {
            var r;
            uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
            uuid[14] = '4';
            for (i = 0; i < 36; i++) {
                if (!uuid[i]) {
                    r = 0 | Math.random() * 16;
                    uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
                }
            }
        }
        return uuid.join('');
    }
}


var getLocation = function (successFunc, errorFunc) { //successFunc获取定位成功回调函数，errorFunc获取定位失败回调
    //首先设置默认城市
    var defCity = {
        id: '000001',
        name: '杭州市',
        date: curDateTime()//获取当前时间方法
    };
    if (storage.getItem('VPIAO_MOBILE_POSITION')) return;
    if (storage.getItem('Postion_MOBILE_Cancel')) return;
    //默认城市
    storage.setItem('VPIAO_MOBILE_CURRENTCITY', JSON.stringify(defCity));
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            var lat = position.coords.latitude;
            var lon = position.coords.longitude;
            //var map = new BMap.Map("container");   // 创建Map实例
            var point = new BMap.Point(lon, lat); // 创建点坐标
            var gc = new BMap.Geocoder();
            gc.getLocation(point, function (rs) {
                var addComp = rs.addressComponents;
                var curCity = {
                    id: '',
                    name: addComp.province,
                    date: curDateTime()
                };
                //当前定位城市
                storage.removeItem("VPIAO_MOBILE_POSITION");
                storage.setItem('VPIAO_MOBILE_POSITION', JSON.stringify(point));
                var str = "";
                for (var key in rs.point) {
                    str += key + ":" + rs.point[key] + ";";
                }
                alert(lat + ',' + lon + '|' + str);
                if (successFunc != undefined)
                    successFunc(addComp);
            });
        },
        function (error) {
            switch (error.code) {
                case 1:
                    storage.setItem('Postion_MOBILE_Cancel', JSON.stringify(curCity));
                    alert("您取消了定位功能。");
                    break;
                case 2:
                    alert("暂时获取不到位置信息。");
                    break;
                case 3:
                    alert("获取位置信息超时。");
                    break;
                default:
                    //                    alert("未知错误。");
                    break;
            }
            var curCity = {
                id: '000001',
                name: '杭州市',
                date: curDateTime()
            };
            //默认城市
            //            storage.setItem('VPIAO_MOBILE_CURRENTCITY', JSON.stringify(curCity));
            //            alert(addComp.province + ", " + addComp.city + ", " + addComp.district + ", " + addComp.street);
            if (errorFunc != undefined)
                errorFunc(error);
        }, { timeout: 5000, enableHighAccuracy: true });
    } else {
        alert("你的浏览器不支持获取地理位置信息。");
        if (errorFunc != undefined)
            errorFunc("你的浏览器不支持获取地理位置信息。");
    }
};
var showPosition = function (position) {
    var lat = position.coords.latitude;
    var lon = position.coords.longitude;
    //var map = new BMap.Map("container");   // 创建Map实例
    var point = new BMap.Point(lon, lat); // 创建点坐标
    var gc = new BMap.Geocoder();
    gc.getLocation(point, function (rs) {
        var addComp = rs.addressComponents;
        var curCity = {
            id: '',
            name: addComp.province,
            date: curDateTime()
        };
        //当前定位城市
        //        $.cookie('VPIAO_MOBILE_CURRENTCITY', JSON.stringify(curCity), { expires: 7, path: '/' });
//        storage.setItem('VPIAO_MOBILE_CURRENTCITY', JSON.stringify(curCity));
//        alert(addComp.province + ", " + addComp.city + ", " + addComp.district + ", " + addComp.street);
    });
};
var showPositionError = function (error) {
    switch (error.code) {
        case 1:
            alert("位置服务被拒绝。");
            break;
        case 2:
            alert("暂时获取不到位置信息。");
            break;
        case 3:
            alert("获取位置信息超时。");
            break;
        default:
            alert("未知错误。");
            break;
    }
    var curCity = {
        id: '000001',
        name: '杭州市',
        date: curDateTime()
    };
    //默认城市
    //    $.cookie('VPIAO_MOBILE_DEFAULTCITY', JSON.stringify(curCity), { expires: 1, path: '/' });
//    storage.setItem('VPIAO_MOBILE_CURRENTCITY', JSON.stringify(curCity));
};
var curDateTime = function () {
    return (new Date()).getTime();
};
getLocation();