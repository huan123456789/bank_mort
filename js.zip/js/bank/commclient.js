﻿var localStorage = window.localStorage;
var publicApi = {
    apiList: {
        bankurl: 'asyncinvoke/bankMortgage.ashx'
    },
    setCache: function (key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    },
    getCache: function (key) {
        var value = localStorage.getItem(key);
        if (value != null && value.hasOwnProperty('express')) {//判断该缓存是否有时效
            var timeout = value.express;
            var curtime = new Date().getTime();
            if (timeout < curtime) {//过期缓存直接清除并返回 null
                localStorage.removeItem(key);
                return null;
            }
        }
        return value != null ? JSON.parse(value) : null;
    },
    guid: function () {
        function S4() { return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1); }
        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
    }
}
//错误信息弹窗
function errormsg(msg) {
    layer.open({
        content: msg
        , anim: 'up'
        , style: ' color:red'
    });
}
//成功消息弹窗,closetime秒后自动关闭
function successmsg(msg, closetime) {
    var ctime = 30;
    if (arguments.length == 2) ctime = closetime;
    layer.open({
        content: msg
        , anim: 'up'
        , style: ' color:green'
        , time: ctime
    });
}
function layermsgtip(msg, closetime, issuccess) {
    var ctime = 3;
    if (arguments.length >= 2) ctime = closetime;
    var styles = ' color:green;';
    if (arguments.length >= 3 && !issuccess) styles = ' color:red;';
    layer.open({
        content: msg
        , style: styles
        , time: ctime //3秒后自动关闭
    });
}
/*layer确认框，确认后会执行事件*/
function layersure(msg, bnttext, yesfn) {
    var btext = arguments.length >= 2 ? bnttext : "确认";
    layer.open({
        content: msg,
        btn: btext,
        shadeClose: false,
        yes: function () {
            if (yesfn) {
                yesfn();
            }
        }
    });
}

function comfirmsg(msg, yestext, notext, yesfn, nofn) {
    layer.closeAll();
    loadindex = layer.open({
        content: msg
    , btn: [yestext, notext]
    , shadeClose: false
    , yes: function (index) {
        layer.close(index);
        if (yesfn) {
            yesfn();
        }
    }
    , no: function (index) {
        layer.close(index);
        if (nofn) {
            nofn();
        }
    }
    });
}

//数据加载样式,参数不传则默认显示 加载中...
var loadindex;
function loading(msg) {
    var m = msg == "" ? '加载中...' : msg;
    loadindex = layer.open({
        type: 2
        , content: m
        , shadeClose: false
    });
}

function closelayer(index) {
    if (arguments.length == 0) {
        layer.closeAll();
    } else {
        layer.close(index);
    }
}
function hideparent() {
    $(this).parent().fadeOut();
}
function hidecontent(parentflag) {
    $(parentflag).fadeOut();
}

//获取参数值
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return '';
}
//删除指定参数
function delQueryString(name) {
    var loca = window.location;
    var baseUrl = loca.origin + loca.pathname + "?";
    var query = loca.search.substr(1);
    if (query.indexOf(name) > -1) {
        var obj = {}
        var arr = query.split("&");
        for (var i = 0; i < arr.length; i++) {
            arr[i] = arr[i].split("=");
            obj[arr[i][0]] = arr[i][1];
        };
        delete obj[name];
        var url = baseUrl + JSON.stringify(obj).replace(/[\"\{\}]/g, "").replace(/\:/g, "=").replace(/\,/g, "&");
        return url
    };
    return window.location.href;
}

Date.prototype.Format = function (fmt) { //author: meizz   
    var o = {
        "M+": this.getMonth() + 1, //月份   
        "d+": this.getDate(), //日   
        "H+": this.getHours(), //小时   
        "m+": this.getMinutes(), //分   
        "s+": this.getSeconds(), //秒   
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度   
        "S": this.getMilliseconds() //毫秒   
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}